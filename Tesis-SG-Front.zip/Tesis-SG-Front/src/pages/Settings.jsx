export default function Settings() {
    return (
      <div className="p-6">
        <h1 className="text-2xl font-bold">Configuración</h1>
        <p>Ajustes del sistema.</p>
      </div>
    );
  }
  